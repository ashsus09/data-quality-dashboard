DATA_PATH = "data/raw_data.csv"
RULES_PATH = "rules/validation_rules.json"
OUTPUT_PATH = "output/"

QUALITY_THRESHOLD = 90